<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Order extends Model {
    use HasFactory;

    protected $fillable = ["order_num", "client_id", "contact_id", "date", "promo_code", "amount", "payment_method", "invoice_id", "status", "ip_address", "fraud_module", "fraud_output", "notes",
        'terms_accepted_at', 'terms_version', 'terms_ip', 'terms_documents',
    ];
    protected function casts(): array { return [
            'terms_accepted_at' => 'datetime',
            'terms_documents' => 'array',"date" => "date", "amount" => "decimal:2"]; }

    public function client() { return $this->belongsTo(Client::class); }
    public function invoice() { return $this->belongsTo(Invoice::class); }
    public function services() { return $this->hasMany(Service::class, "order_id"); }
    public function domains() { return $this->hasMany(Domain::class, "order_id"); }

    /**
     * The currency `amount` is in. Orders have no currency column: the amount
     * is the shop's, which the order's invoice records as its source currency.
     */
    public function currencyCode(): string
    {
        return strtoupper((string) ($this->invoice?->source_currency ?: Currency::getDefault()?->code ?: 'USD'));
    }
}
