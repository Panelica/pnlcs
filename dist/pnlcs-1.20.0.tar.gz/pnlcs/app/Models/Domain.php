<?php

namespace App\Models;

use App\Casts\EncryptedValue;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Domain extends Model
{
    use HasFactory;

    /**
     * The transfer code is decrypted by its cast and was serialised with every
     * domain, so getclientsdomains handed any caller allowed to list domains
     * the code that moves each one to another registrar. domainrequestepp is
     * the one door for it, one domain at a time.
     */
    protected $hidden = ['epp_code'];

    protected $fillable = ['client_id', 'order_id', 'type', 'domain', 'epp_code', 'registrar', 'registrar_contact_id', 'registration_period', 'registration_date', 'expiry_date', 'next_due_date', 'status', 'dns_management', 'email_forwarding', 'id_protection', 'is_premium', 'payment_method', 'first_payment_amount', 'recurring_amount', 'nameservers', 'notes', 'last_sync_at', 'last_sync_status', 'renewal_reminder_stage', 'renewal_reminder_sent_at'];

    protected function casts(): array
    {
        return ['registration_date' => 'date', 'expiry_date' => 'date', 'next_due_date' => 'date', 'last_sync_at' => 'datetime', 'renewal_reminder_sent_at' => 'datetime', 'epp_code' => EncryptedValue::class, 'dns_management' => 'boolean', 'email_forwarding' => 'boolean', 'id_protection' => 'boolean', 'is_premium' => 'boolean', 'first_payment_amount' => 'decimal:2', 'recurring_amount' => 'decimal:2'];
    }

    /**
     * The nameservers on record, in order. The column holds a JSON list or
     * object (ns1 => ...) written by different paths; this reads either.
     *
     * @return list<string>
     */
    public function nameserverList(): array
    {
        $raw = $this->nameservers;
        $list = is_array($raw) ? $raw : (json_decode((string) ($raw ?? ''), true) ?: []);

        return array_values(array_filter(array_map(fn ($v) => trim((string) $v), (array) $list)));
    }

    /**
     * Whether this domain is set to renew.
     *
     * There is no column for it. The customer's switch flips payment_method to
     * "none", and that is what the invoice generator reads - a null counts as
     * renewing, the same way it does there. The screens used to read a
     * non-existent attribute and therefore always said no.
     */
    public function getAutoRenewAttribute(): bool
    {
        return ($this->payment_method ?? '') !== 'none';
    }

    /**
     * The domain a customer meant, from whatever they typed.
     *
     * The search box lower-cased its input and the order form did not, so the
     * same address arrived in two shapes depending on which box it went in.
     * People also paste URLs rather than domains, and a scheme, a www or a
     * trailing dot would be handed to the panel and the registrar as part of
     * the name.
     */
    public static function normalise(?string $domain): string
    {
        $domain = strtolower(trim((string) $domain));

        if ($domain === '') {
            return '';
        }

        // Scheme, then anything after the host: a pasted address brings both.
        $domain = preg_replace('#^[a-z][a-z0-9+.-]*://#', '', $domain) ?? $domain;
        $domain = preg_split('#[/?\#]#', $domain)[0] ?? $domain;

        // Credentials and a port, if the paste carried them.
        if (str_contains($domain, '@')) {
            $domain = substr($domain, strrpos($domain, '@') + 1);
        }
        $domain = preg_replace('/:\d+$/', '', $domain) ?? $domain;

        // "www." is a host under the domain, never the domain being ordered.
        // Only as a label of its own: wwwshop.com keeps its name.
        if (str_starts_with($domain, 'www.')) {
            $domain = substr($domain, 4);
        }

        return trim($domain, '.');
    }

    /**
     * A paid registration still waiting for its registrar: pending, not a
     * transfer (that needs the EPP code, started by hand), and naming a
     * registrar to send it to.
     */
    public function awaitsRegistration(): bool
    {
        return strtolower((string) $this->status) === \App\Enums\DomainStatus::Pending->value
            && strtolower((string) $this->type) !== 'transfer'
            && trim((string) $this->registrar) !== '';
    }

    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    public function order()
    {
        return $this->belongsTo(Order::class);
    }
}
